#include <common.h>
#include <monitor.h>
void kernel_main() {
	monitor_write("Hi Welcome to MatrixOS2!");
}
